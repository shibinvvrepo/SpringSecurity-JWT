package com.svv;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.svv.model.UserName;
import com.svv.repository.UserRepo;

@SpringBootApplication
public class Demo26PracticeJwtApplication {
	
	public static int step=0;
	
	@Autowired
	UserRepo userRepo;
	
	@PostConstruct
	public void init()
	{
		List<UserName> userList = Stream.of(new UserName(1,"shibin","123",""),new UserName(2,"shibin1","123","")).
		collect(Collectors.toList());
		userRepo.saveAll(userList);
	}

	public static void main(String[] args) {
		SpringApplication.run(Demo26PracticeJwtApplication.class, args);
	}
	
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		Demo26PracticeJwtApplication.logSteps(this.getClass(),"passwordEncoder()");;
		return NoOpPasswordEncoder.getInstance();
	}
	
	public static void logSteps(Class classname,String method)
	{
		step = step+1;
	    System.out.println(step+"-->"+classname.getName().toString().split("$$")[0]+" - "+method);

	}

}
