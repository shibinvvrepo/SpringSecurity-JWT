package com.svv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svv.Demo26PracticeJwtApplication;
import com.svv.model.AuthRequest;
import com.svv.model.AuthResponse;
import com.svv.service.CustomUserDetailsService;
import com.svv.utility.JWTUtility;

@RestController
public class JWTController {
	
	@Autowired
	private JWTUtility jwtUtility;
	
	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private CustomUserDetailsService userDetailService;
	
	@GetMapping("/")
	public String welcome()
	{
		Demo26PracticeJwtApplication.logSteps(this.getClass(),"welcome()");
		return "Hi, Welcome ";

	}
	
	@PostMapping("/authenticate")
	public String authenticate(@RequestBody AuthRequest req) throws Exception
	{
		Demo26PracticeJwtApplication.logSteps(this.getClass(),"authenticate(@RequestBody AuthRequest req)");
		try {
			authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUserName(),req.getPassword()));
			
		} catch (BadCredentialsException e) {
			throw new Exception("Invalid credential",e);
		}
		
		return jwtUtility.generateToken(req.getUserName());

	}

}
