package com.svv.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.svv.model.UserName;

@Repository
public interface UserRepo extends JpaRepository<UserName, Integer> {
	UserName findByUserName(String username);
}
