package com.svv.service;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.svv.Demo26PracticeJwtApplication;
import com.svv.model.UserName;
import com.svv.repository.UserRepo;

@Service
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UserRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Demo26PracticeJwtApplication.logSteps(this.getClass(),"loadUserByUsername(String username)");
		UserName userObj = userRepo.findByUserName(username);
		
	    return new org.springframework.security.core.userdetails.User(userObj.getUserName(), userObj.getPassword(),new ArrayList<>());
	}

}
